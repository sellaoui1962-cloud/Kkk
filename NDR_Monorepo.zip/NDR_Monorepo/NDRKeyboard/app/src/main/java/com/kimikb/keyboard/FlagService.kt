package com.kimikb.keyboard

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import android.widget.FrameLayout
import android.widget.TextView

/**
 * 1) يقرأ آخر رسالة فيها أعلام فقط (مثل 🇫🇷) في شاشة الغرفة.
 * 2) يضغط زر الإرسال الأخضر (حسب المعايرة 📍، أو بالبحث التلقائي).
 * كل العمل الثقيل في خيط خلفي حتى لا يتوقف التطبيق.
 */
class FlagService : AccessibilityService() {

    companion object {
        @Volatile var instance: FlagService? = null
        @Volatile var watching = false
        @Volatile var listener: ((List<String>) -> Unit)? = null
        @Volatile var last: List<String> = emptyList()
        @Volatile var lastError: String = ""
    }

    private val main = Handler(Looper.getMainLooper())
    private var thread: HandlerThread? = null
    private var bg: Handler? = null
    @Volatile private var scheduled = false
    private var lastCount = 0

    override fun onServiceConnected() {
        super.onServiceConnected()
        thread = HandlerThread("kb-flag").also { it.start() }
        bg = Handler(thread!!.looper)
        instance = this
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        if (instance === this) instance = null
        thread?.quitSafely()
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (!watching || scheduled) return
        if (e?.packageName?.toString() == packageName) return   // تجاهل أحداث الكيبورد نفسه
        scheduled = true
        bg?.postDelayed({ scheduled = false; doScan(false) }, 400)
    }

    // ---------- helpers ----------

    private fun appRoots(): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        runCatching {
            for (w in windows) {
                if (w.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD) continue
                w.root?.let { out.add(it) }
            }
        }
        if (out.isEmpty()) rootInActiveWindow?.let { out.add(it) }
        return out
    }

    private fun imeTop(): Int {
        val r = Rect()
        runCatching {
            for (w in windows) {
                if (w.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD) {
                    w.getBoundsInScreen(r)
                    return r.top
                }
            }
        }
        return -1
    }

    private inline fun walk(root: AccessibilityNodeInfo, limit: Int = 1800, f: (AccessibilityNodeInfo) -> Unit) {
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(root)
        var n = 0
        while (stack.isNotEmpty() && n < limit) {
            val node = stack.removeLast()
            n++
            f(node)
            for (i in 0 until node.childCount) node.getChild(i)?.let { stack.add(it) }
        }
    }

    // ---------- flag reading ----------

    /** يمسح الشاشة في الخلفية. silent = حدّث الحالة بدون إشعار الكيبورد. */
    fun scanNow(silent: Boolean = false) {
        bg?.post { doScan(silent) }
    }

    private fun doScan(silent: Boolean) {
        try {
            var bestTop = Int.MIN_VALUE
            var best: List<String>? = null
            var count = 0
            val r = Rect()
            for (root in appRoots()) {
                walk(root) { node ->
                    val t = node.text?.toString() ?: node.contentDescription?.toString()
                    val fl = FlagData.parseFlags(t)
                    if (fl != null && node.isVisibleToUser) {
                        count++
                        node.getBoundsInScreen(r)
                        if (r.top > bestTop) { bestTop = r.top; best = fl }
                    }
                }
            }
            val b = best
            if (b == null) { lastCount = 0; return }
            val fresh = b != last || count > lastCount
            last = b
            lastCount = count
            if (fresh && !silent) main.post {
                try { listener?.invoke(b) } catch (t: Throwable) { lastError = t.toString() }
            }
        } catch (t: Throwable) {
            lastError = t.toString()
        }
    }

    // ---------- green send button ----------

    private fun screenW() = resources.displayMetrics.widthPixels
    private fun screenH() = resources.displayMetrics.heightPixels

    private fun tap(x: Float, y: Float) {
        val p = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 50)).build()
        dispatchGesture(g, null, null)
    }

    /** يضغط الزر الأخضر. onDone(true) إن نُفّذت ضغطة. */
    fun clickGreenSend(onDone: ((Boolean) -> Unit)? = null) {
        val h = bg ?: run { onDone?.invoke(false); return }
        h.post {
            val ok = try { doClick() } catch (t: Throwable) { lastError = t.toString(); false }
            if (onDone != null) main.post { onDone(ok) }
        }
    }

    private fun doClick(): Boolean {
        val prefs = getSharedPreferences("kb_prefs", MODE_PRIVATE)
        // 1) المكان المعايَر يدوياً (الأدق): x نسبة من العرض، y = أعلى الكيبورد − المسافة المحفوظة
        if (prefs.contains("send_x")) {
            val x = prefs.getFloat("send_x", 0f) * screenW()
            val top = imeTop()
            val y = if (top > 0 && prefs.contains("send_dy")) top - prefs.getFloat("send_dy", 0f)
            else prefs.getFloat("send_y", 0.5f) * screenH()
            main.post { tap(x, y) }
            return true
        }
        // 2) بحث تلقائي: أقصى زر قابل للضغط يسار خانة الكتابة
        val er = Rect()
        val r = Rect()
        for (root in appRoots()) {
            var edit: AccessibilityNodeInfo? = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            if (edit == null) walk(root) { n ->
                if (edit == null && n.isEditable && n.isVisibleToUser) edit = n
            }
            val e = edit ?: continue
            e.getBoundsInScreen(er)
            var target: AccessibilityNodeInfo? = null
            var targetLeft = Int.MAX_VALUE
            walk(root) { n ->
                if (n.isClickable && n.isVisibleToUser && !n.isEditable) {
                    n.getBoundsInScreen(r)
                    val fits = r.centerY() in (er.top - 20)..(er.bottom + 20) &&
                        r.right <= er.left + 20 && r.width() < screenW() / 4
                    if (fits && r.left < targetLeft) { targetLeft = r.left; target = n }
                }
            }
            val t = target
            if (t != null) {
                if (t.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                t.getBoundsInScreen(r)
                val cx = r.exactCenterX(); val cy = r.exactCenterY()
                main.post { tap(cx, cy) }
                return true
            }
            val cy = er.centerY().toFloat()
            main.post { tap(screenW() * 0.07f, cy) }
            return true
        }
        return false
    }

    // ---------- 📍 calibration: user touches the green button once ----------

    fun startCalibration(onDone: (Boolean) -> Unit) {
        main.post {
            try {
                val wm = getSystemService(WINDOW_SERVICE) as WindowManager
                val v = FrameLayout(this)
                v.setBackgroundColor(0x99000000.toInt())
                val tv = TextView(this).apply {
                    text = "📍 المس مكان زر الإرسال الأخضر بالضبط\n\n(اكتب حرفاً في الخانة أولاً ليظهر الزر الأخضر)"
                    setTextColor(Color.WHITE)
                    textSize = 18f
                    gravity = Gravity.CENTER
                    setPadding(48, 48, 48, 48)
                }
                v.addView(tv, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))
                val lp = WindowManager.LayoutParams(
                    -1, -1, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT)
                v.setOnTouchListener { _, e ->
                    if (e.actionMasked == MotionEvent.ACTION_UP) {
                        val x = e.rawX; val y = e.rawY
                        val top = imeTop()
                        val ed = getSharedPreferences("kb_prefs", MODE_PRIVATE).edit()
                            .putFloat("send_x", x / screenW())
                            .putFloat("send_y", y / screenH())
                        if (top > 0) ed.putFloat("send_dy", top - y) else ed.remove("send_dy")
                        ed.apply()
                        runCatching { wm.removeView(v) }
                        onDone(true)
                    }
                    true
                }
                wm.addView(v, lp)
            } catch (t: Throwable) {
                lastError = t.toString()
                onDone(false)
            }
        }
    }
}
