package com.kimikb.keyboard

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.os.Build
import org.json.JSONObject
import org.vosk.Recognizer
import kotlin.math.abs

/**
 * Captures audio (the room's playback via MediaProjection, or the microphone) and feeds it
 * to Vosk. Results are pushed to SttBridge.sink.
 */
class SttEngine(
    private val ctx: Context,
    private val lang: String,
    private val projection: MediaProjection?
) {
    @Volatile private var running = false
    private var thread: Thread? = null
    private val sink = SttBridge.sink
    private val rate = 16000

    fun start() {
        running = true
        thread = Thread({ loop() }, "stt-engine").also { it.start() }
    }

    fun stop() { running = false }

    @SuppressLint("MissingPermission")
    private fun buildRecord(bufSize: Int): AudioRecord {
        if (projection != null && Build.VERSION.SDK_INT >= 29) {
            val cfg = AudioPlaybackCaptureConfiguration.Builder(projection)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()
            val fmt = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(rate)
                .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                .build()
            return AudioRecord.Builder()
                .setAudioFormat(fmt)
                .setBufferSizeInBytes(bufSize)
                .setAudioPlaybackCaptureConfig(cfg)
                .build()
        }
        return AudioRecord(MediaRecorder.AudioSource.MIC, rate,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufSize)
    }

    private fun text(json: String, key: String): String =
        runCatching { JSONObject(json).optString(key, "") }.getOrDefault("").trim()

    private fun loop() {
        var rec: AudioRecord? = null
        var recognizer: Recognizer? = null
        try {
            sink.onState("loading")
            val model = SttModels.model(ctx, lang)
            recognizer = Recognizer(model, rate.toFloat())
            val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT)
            rec = buildRecord(maxOf(min, rate) * 2)
            if (rec.state != AudioRecord.STATE_INITIALIZED)
                throw IllegalStateException("AudioRecord init failed")
            rec.startRecording()
            sink.onState("listening")

            val buf = ShortArray(4000)
            var silentMs = 0L
            var warned = false
            var lastPartial = ""
            while (running) {
                val n = rec.read(buf, 0, buf.size)
                if (n < 0) throw IllegalStateException("read error $n")
                if (n == 0) continue

                var peak = 0
                for (i in 0 until n) { val a = abs(buf[i].toInt()); if (a > peak) peak = a }
                if (peak < 20) {
                    silentMs += n * 1000L / rate
                    if (!warned && silentMs > 12000) {
                        warned = true
                        sink.onError(if (projection != null)
                            "لا يصل أي صوت — ربما التطبيق يمنع التقاط صوته. جرّب وضع المايك 🎤"
                        else "لا يصل صوت من المايك — تأكد أنك تتكلم، أو فعّل خدمة إمكانية الوصول للكيبورد")
                    }
                } else { silentMs = 0; warned = false }

                if (recognizer.acceptWaveForm(buf, n)) {
                    val t = text(recognizer.result, "text")
                    lastPartial = ""
                    if (t.isNotEmpty()) sink.onFinal(t) else sink.onPartial("")
                } else {
                    val p = text(recognizer.partialResult, "partial")
                    if (p != lastPartial) { lastPartial = p; sink.onPartial(p) }
                }
            }
            val tail = text(recognizer.finalResult, "text")
            if (tail.isNotEmpty()) sink.onFinal(tail)
        } catch (t: Throwable) {
            sink.onError("خطأ في التعرف: " + (t.message ?: t.javaClass.simpleName))
        } finally {
            runCatching { rec?.stop() }
            runCatching { rec?.release() }
            runCatching { recognizer?.close() }
            sink.onPartial("")
            sink.onState("stopped")
        }
    }
}
