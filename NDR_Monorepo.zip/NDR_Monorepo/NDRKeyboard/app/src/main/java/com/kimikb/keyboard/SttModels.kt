package com.kimikb.keyboard

import android.content.Context
import org.vosk.Model
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/** Offline Vosk models: downloaded once into app storage, then loaded from disk. */
object SttModels {
    // Change a name here if you want a bigger / better model for that language.
    private val names = mapOf(
        "ar" to "vosk-model-small-ar-tn-0.1-linto",
        "fr" to "vosk-model-small-fr-0.22",
        "en" to "vosk-model-small-en-us-0.15"
    )

    fun url(lang: String) = "https://alphacephei.com/vosk/models/${names[lang]}.zip"
    private fun dir(ctx: Context, lang: String) = File(ctx.filesDir, "vosk/${names[lang]}")
    fun ready(ctx: Context, lang: String) = File(dir(ctx, lang), "ready").exists()

    private var cachedLang: String? = null
    private var cached: Model? = null

    @Synchronized
    fun model(ctx: Context, lang: String): Model {
        if (cachedLang == lang && cached != null) return cached!!
        runCatching { cached?.close() }
        val m = Model(dir(ctx, lang).absolutePath)
        cached = m; cachedLang = lang
        return m
    }

    fun download(ctx: Context, lang: String, onProgress: (Int) -> Unit) {
        val target = dir(ctx, lang)
        target.deleteRecursively()
        target.mkdirs()
        val conn = URL(url(lang)).openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        conn.connect()
        if (conn.responseCode != 200) throw IllegalStateException("HTTP ${conn.responseCode}")
        val total = conn.contentLengthLong
        var read = 0L
        var lastPct = -1
        ZipInputStream(conn.inputStream.buffered(1 shl 16)).use { zin ->
            val buf = ByteArray(1 shl 16)
            while (true) {
                val e = zin.nextEntry ?: break
                // drop the top-level folder of the zip so am/ conf/ graph/ sit directly in target
                val rel = e.name.substringAfter('/', "")
                if (rel.isEmpty()) continue
                val out = File(target, rel)
                if (!out.canonicalPath.startsWith(target.canonicalPath)) continue   // zip-slip guard
                if (e.isDirectory) { out.mkdirs(); continue }
                out.parentFile?.mkdirs()
                out.outputStream().use { os ->
                    while (true) {
                        val n = zin.read(buf)
                        if (n < 0) break
                        os.write(buf, 0, n)
                        read += n
                    }
                }
                if (total > 0) {
                    // zip is compressed, so this is only an estimate; cap at 99 until done
                    val pct = ((read * 100) / (total * 2)).toInt().coerceIn(0, 99)
                    if (pct != lastPct) { lastPct = pct; onProgress(pct) }
                }
            }
        }
        if (!File(target, "am").exists()) throw IllegalStateException("model files missing")
        File(target, "ready").writeText("1")
        onProgress(100)
    }
}
