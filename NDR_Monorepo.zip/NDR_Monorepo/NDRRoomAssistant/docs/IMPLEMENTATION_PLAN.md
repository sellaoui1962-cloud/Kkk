# IMPLEMENTATION_PLAN
1. Scaffold NDRRoomAssistant (com.ndr.assistant, Kotlin, Gradle 8.7, AGP matching nMic).
2. Port nMic engine/classifier/seat finder -> features/mic (as is, rename package).
3. Port nTag mention engine/seat detector/timer -> features/tagging.
4. core/accessibility: single NdrAccessibilityService dispatching to active mode.
5. core/capture: CaptureManager (takeScreenshot API30+, MediaProjection fallback).
6. floating/: expandable switcher [MIC][TAG], drag, minimize, close, settings, mode StateFlow.
7. Keyboard: bottom Send key, rename to NDR Keyboard (applicationId com.ndr.keyboard).
8. Docs + tests (JUnit for logic; instrumented tests listed but need device).
Each step must be compiled on a machine with Android SDK (GitHub Actions workflows already exist in all three projects).
