# KNOWN_LIMITATIONS
- Nothing here has been compiled or run; expect a round of compiler fixes.
- No APK was produced (sandbox has no Android SDK/Gradle/network).
- nTag works by screenshot template-matching of mic seats and a timer, NOT by reading participant names. "Search participants / suggest names from the screen" is not implemented; it needs a new feature (accessibility node text first, OCR fallback).
- ML Kit text-recognition 16.0.0 is Latin-only: no Arabic OCR. Arabic needs another engine or accessibility text.
- TAG mode needs Android 11+ (takeScreenshot). MIC mode works from Android 8.
- Switching to TAG pauses MIC processing but keeps the MediaProjection session alive (so switching back needs no new consent); the capture notification stays visible.
- Starting an activity from the switcher's settings button may be blocked by Android background-start rules on some devices.
- NDR Keyboard keeps applicationId com.kimikb.keyboard so your installed settings/IME selection carry over. The Send key (bottom row, IME_ACTION fallback, green-send helper) already existed in v4.3; no new keyboard logic was added or tested. Darija dictation quality depends on the Vosk model and was not evaluated.
- Yalla Ludo: shipped as a split bundle (base + asset pack + arm64). Repackaging breaks the signature, likely breaks login and violates the game's terms; whether chat/sticker repeat limits are local or server-side is unknown. Not modified. Server rate limits would not be bypassed in any case.
