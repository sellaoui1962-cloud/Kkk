# TEST_REPORT
Executed: **nothing on a device, no Gradle tests.** Only the static checks listed in BUILD_REPORT.md.

Unit tests present (from nTag, not run): app/src/test/.../tag/LogicTest.kt (mention suffix alternation, timer tracker).

Manual checklist to run after the first successful build (all UNTESTED):
- [ ] Enable "NDR Room Assistant" in Accessibility; the small N icon appears.
- [ ] Tap N -> [MIC] [TAG] panel; drag the icon; long-press hides it; "NDR MIC / TAG" button in the app shows it again.
- [ ] MIC: grant screen capture once; MIC panel appears; switching to TAG pauses it.
- [ ] TAG (Android 11+): bubble + circles appear; switching to MIC removes them and stops the loop.
- [ ] Switch MIC->TAG->MIC 10x: no duplicate overlays, no crash, no second accessibility service in settings.
- [ ] TAG on Android 8-10: TAG button dimmed, toast explains.
- [ ] Shizuku absent: MIC taps still work through accessibility gestures.
- [ ] Keyboard: Arabic/English typing, Send key in a chat field, voice typing.
No performance numbers exist; none were measured.
