# NDR Room Assistant - install & permissions (after you build it)
1. Build: push NDRRoomAssistant to GitHub (Actions builds the debug APK) or `gradle :app:assembleDebug`.
2. Install the APK; open the app.
3. Settings > Accessibility > NDR Room Assistant > On. This single service provides taps (MIC), screenshots (TAG), and the floating switcher.
4. MIC mode: when asked, allow screen capture (one-time per session). Shizuku is optional.
5. TAG mode: Android 11+. No extra permission beyond the accessibility service.
6. Use the small N icon: tap = [MIC][TAG]; drag to move; long-press = hide (the app's "NDR MIC / TAG" button brings it back).
NDR Keyboard: install it separately, enable it in Settings > Languages & input, and pick it as the active keyboard.
