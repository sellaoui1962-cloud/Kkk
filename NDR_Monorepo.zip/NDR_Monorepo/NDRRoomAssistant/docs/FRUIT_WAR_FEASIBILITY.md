# FRUIT WAR / MYSTERY BOX — FEASIBILITY REPORT
Method: static analysis only (binary AndroidManifest parsed by hand, dex string-pool extraction with a small custom script, asset-pack file listing). No decompiled Smali/Java, no running instance, no network capture. Everything below is sourced from Yalla Ludo 1.5.0.0 (base.apk + split_appAssetPack.apk + split_config.arm64_v8a.apk).

## PROVEN (directly observed in the APK)
1. The app bundles a `room.proto` schema (package `roomuser`) with messages:
   - `Message9000 { fruitstatus, startuser, winneruser }` — a pure status/result broadcast (not a reveal of contents).
   - `Message9001 { treasurestate, startuser }` — same pattern for the "Treasure" mini-game.
   - `Message10049` (a room-game status push) carries `fruitState`, `treasurestate`, and — critically — `roomgamewebsocket` and `roomgameurl` / `treasuregameurl` fields.
2. The asset pack (`split_appAssetPack.apk`, ~64 MB) contains no file with "fruit", "mystery", "treasure", "luckybox" or "blindbox" in its name anywhere under `assets/`. Its `assets/ylgame/*` folder (385 files: html/css/js) is rule/guide/webview content (battle pass, domino skin, VIP room, etc.) — not a mini-game board.
3. Native libraries include `liblayaair.so`, `liblayair-gl.so`, `liblayakx.so` (the LayaAir engine, an HTML5/JS game runtime commonly used by this class of app for small room mini-games) alongside `libgtc4core.so` (the main board-game engine). Two separate engines exist in the same APK.
4. `room.proto` additionally defines a full gRPC-style web API (`roomWebApi`) for rooms, shop, gifts, etc. — none of its ~400 messages expose a "current fruit", "box contents", or "upcoming result" field readable before a round starts.

## CONCLUSION FROM THE PROVEN FACTS
Fruit War's and the mystery/treasure box's outcome data is **not shipped as a static local asset** and is **not exposed as a pre-reveal field** in any protobuf message found. The `roomgameurl` / `roomgamewebsocket` fields strongly indicate these mini-games are delivered as a small remote web/JS game (likely via the bundled LayaAir runtime) fetched and driven over the network at the moment the game starts, with its own dedicated websocket — separate from the main room protocol.

## HYPOTHESIS (not proven by this analysis — would need a decompiled client, a live capture of `roomgamewebsocket` traffic, or a rooted-device runtime trace to confirm)
- The fruit/box result is most likely selected server-side and streamed to the client only at reveal time, which is the standard design for this kind of socket-driven mini-game and consistent with "winneruser" only appearing in the status message, never before.
- It is *possible* (not shown) that the remote mini-game client receives the full outcome slightly before animating it (a common pattern to let the client animate smoothly) — this would be a timing/race condition, not a locally stored secret, and confirming or exploiting it would require intercepting that websocket's live traffic, which this sandbox cannot do (no network) and which I did not attempt.

## FEASIBILITY VERDICT
**Not feasible from information available locally in this client**, based on what was actually inspected. No evidence exists in this APK of client-side predetermination. I did not find and am not claiming any way to see fruit or box contents before selection.

## WHAT WAS NOT DONE (and why)
- No Smali/Java decompilation of the obfuscated classes (`DeepLinkRouteActivity$OooO...` etc.) — would need `apktool`/`jadx`, unavailable in this sandbox.
- No live traffic capture of `roomgamewebsocket` — needs network access and a running room, unavailable here, and would also mean intercepting the live game, which risks touching server-side anti-cheat/rate-limit systems I was told not to bypass.
- No modification of the original APK was made or attempted, per the instructions.
