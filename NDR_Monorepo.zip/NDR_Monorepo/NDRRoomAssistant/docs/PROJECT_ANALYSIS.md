# PROJECT_ANALYSIS (Phase 1-2, inspected 2026-11-01)

## Environment
- Sandbox has JDK 21 only. NO Android SDK, NO Gradle, NO kotlinc, NO network.
- Consequence: nothing can be compiled or tested here. No APK can be produced in this session.

## Inputs
| Input | Package | minSdk | Lang | LOC | Key deps |
|---|---|---|---|---|---|
| KimikbKeyboard v4.3 | com.kimikb.keyboard | 24 | Kotlin | ~3.8k | Vosk 0.3.47, JNA |
| ndrXmic v3.1 | com.ndrx.mic | 26 | Kotlin | ~4.8k | Shizuku 13.1.5, AIDL |
| NTag v1.0 | com.ntag.app (ns com.example.mentionassist) | 30 | Kotlin | ~1.8k | ML Kit text-recognition (Latin), coroutines |
| Yalla Ludo 1.5.0.0 | com.yalla.yallagames | 21 | split bundle | - | 12 dex files, base.apk 157MB + asset pack + arm64 split |

## Merge findings (nMic + nTag)
- Both are AccessibilityServices (ClickService / AssistService) -> must become ONE service (requirement: no duplicate a11y services).
- Capture differs: nMic = MediaProjection ImageReader at half-res (CaptureService); nTag = AccessibilityService.takeScreenshot (API 30+). Unify behind one CaptureManager; prefer takeScreenshot on API30+, MediaProjection fallback for 26-29.
- Overlays differ: nMic panel built in ClickService (buildPanel, dragBy, chips); nTag OverlayManager (bubble + seat circles). Floating MIC/TAG switcher = new view owning a mode StateFlow; reuse nMic dragBy and nTag bubble.
- Packages: pick com.ndr.assistant; move nMic -> features/mic, nTag -> features/tagging; shared core/{capture,accessibility,permissions}.
- minSdk of merged app = 26 (TAG mode gated to API 30+).
- Arabic OCR: NTag uses Latin-only ML Kit. Arabic OCR needs another engine (e.g. Tesseract ara data); ML Kit does not support Arabic. Accessibility node text is the primary path.
- Shizuku: nMic already has it (ITapService.aidl, ShizukuProvider). Keep optional.

## Keyboard findings
- MyKeyboardService already calls performEditorAction (custom id / app action / IME_ACTION_SEND) with Enter key fallback (lines ~533-539). A dedicated Send key at the bottom row may be mostly a layout change in KeyboardView.
- Vosk gives offline AR/FR/EN; Darija quality depends on the model (not verified).

## Yalla Ludo
- Delivered as a split bundle (needs SAI/bundletool to install), not a single APK. Original signature would be lost on any repack; official account/login may break.
- Chat/sticker repeat limits: source unknown (local vs server). Cannot be determined without decompiling and running the app. No dex analysis tools in sandbox.
- Decision: do NOT repackage the third-party game in this session. Repeated-text/sticker goals can be met on the keyboard side (Send key, fast re-send) without touching the game. Server limits will not be bypassed.
