# RESUME
Next exact action: Phase 4 - create NDRRoomAssistant scaffold and copy mic/ and tag/ sources into features/mic and features/tagging (package com.ndr.assistant), merge manifests into one a11y service.
Working copies: /home/claude/work/{kb,mic,tag} (extracted from uploads; originals untouched).
Build must run where Android SDK + network exist (GitHub Actions workflows are in each project).
