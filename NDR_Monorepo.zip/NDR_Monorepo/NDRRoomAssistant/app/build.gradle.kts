plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.ndr.assistant"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.ndr.assistant"
        minSdk = 26            // MIC mode works from 26; TAG mode needs 30 (takeScreenshot)
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    buildFeatures { aidl = true }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("dev.rikka.shizuku:api:13.1.5")          // optional, never required
    implementation("dev.rikka.shizuku:provider:13.1.5")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-ktx:1.9.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("com.google.mlkit:text-recognition:16.0.0") // Latin OCR fallback (offline)
    testImplementation("junit:junit:4.13.2")
}
