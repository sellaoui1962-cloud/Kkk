package com.ndr.assistant.mic

/**
 * Counts the mic seats straight from the screen, whatever the room layout is:
 * finds the round avatars / seat discs (circle voting on edges), groups them in rows,
 * fills the seats that are hidden (empty or locked ones have no avatar) using the row spacing,
 * and returns every seat with its own size (big mic -> big frame, small mic -> small frame).
 */
object SeatFinder {
    private var lumBuf = FloatArray(0)
    private var magBuf = FloatArray(0)
    private var acc = IntArray(0)
    private var best = FloatArray(0)
    private var bestR = IntArray(0)

    private class P(val x: Float, val y: Float, val r: Float)

    fun find(f: Frame): List<Slot> {
        val w = f.w
        val y0 = (0.42f * w).toInt()
        val y1 = Math.min(f.h - 2, (1.75f * w).toInt())
        val rh = y1 - y0
        if (rh < 60 || w < 100) return emptyList()
        val n = w * rh
        if (lumBuf.size < n) {
            lumBuf = FloatArray(n); magBuf = FloatArray(n); acc = IntArray(n)
            best = FloatArray(n); bestR = IntArray(n)
        }
        for (y in 0 until rh) {
            val row = y * w
            for (x in 0 until w) lumBuf[row + x] = f.lum(x, y + y0)
        }
        java.util.Arrays.fill(magBuf, 0, n, 0f)
        val hist = IntArray(601)
        var inner = 0
        for (y in 1 until rh - 1) {
            val row = y * w
            for (x in 1 until w - 1) {
                val i = row + x
                val gx = lumBuf[i + 1] - lumBuf[i - 1]
                val gy = lumBuf[i + w] - lumBuf[i - w]
                val m = Math.sqrt((gx * gx + gy * gy).toDouble()).toFloat()
                magBuf[i] = m
                hist[Math.min(600, m.toInt())]++
                inner++
            }
        }
        val target = inner * 88L / 100L
        var cum = 0L
        var t = 0
        while (t < 600) { cum += hist[t]; if (cum >= target) break; t++ }
        val thr = Math.max(40f, t.toFloat())

        var ne = 0
        for (i in 0 until n) if (magBuf[i] > thr) ne++
        if (ne < 200) return emptyList()
        val eX = IntArray(ne)
        val eY = IntArray(ne)
        val eUx = FloatArray(ne)
        val eUy = FloatArray(ne)
        var k = 0
        for (y in 1 until rh - 1) {
            val row = y * w
            for (x in 1 until w - 1) {
                val i = row + x
                val m = magBuf[i]
                if (m > thr) {
                    eX[k] = x; eY[k] = y
                    eUx[k] = (lumBuf[i + 1] - lumBuf[i - 1]) / m
                    eUy[k] = (lumBuf[i + w] - lumBuf[i - w]) / m
                    k++
                }
            }
        }

        java.util.Arrays.fill(best, 0, n, 0f)
        val rmin = Math.max(8, (0.058f * w).toInt())
        val rmax = (0.11f * w).toInt()
        var r = rmin
        while (r <= rmax) {
            java.util.Arrays.fill(acc, 0, n, 0)
            for (e in 0 until ne) {
                for (s in 0..1) {
                    val sg = if (s == 0) 1f else -1f
                    val cx = Math.round(eX[e] + sg * r * eUx[e])
                    val cy = Math.round(eY[e] + sg * r * eUy[e])
                    if (cx < 1 || cx >= w - 1 || cy < 1 || cy >= rh - 1) continue
                    val c = cy * w + cx
                    acc[c - w - 1]++; acc[c - w]++; acc[c - w + 1]++
                    acc[c - 1]++; acc[c]++; acc[c + 1]++
                    acc[c + w - 1]++; acc[c + w]++; acc[c + w + 1]++
                }
            }
            val norm = 1f / (2f * Math.PI.toFloat() * r)
            for (i in 0 until n) {
                val v = acc[i]
                if (v > 0) {
                    val sc = v * norm
                    if (sc > best[i]) { best[i] = sc; bestR[i] = r }
                }
            }
            r += 2
        }

        val peaks = ArrayList<P>()
        val fw = w.toFloat()
        while (peaks.size < 40) {
            var bi = -1
            var bv = 0.16f
            for (i in 0 until n) if (best[i] > bv) { bv = best[i]; bi = i }
            if (bi < 0) break
            val cy = bi / w
            val cx = bi % w
            val rr = bestR[bi]
            peaks.add(P(cx / fw, (cy + y0) / fw, rr / fw))
            val d = (0.9f * rr).toInt()
            for (yy in Math.max(0, cy - d)..Math.min(rh - 1, cy + d)) {
                for (xx in Math.max(0, cx - d)..Math.min(w - 1, cx + d)) best[yy * w + xx] = 0f
            }
        }
        return assemble(peaks)
    }

    private fun minGap(xs: List<Float>): Float {
        var g = 9f
        for (i in 1 until xs.size) { val d = xs[i] - xs[i - 1]; if (d < g) g = d }
        return g
    }

    private fun median(v: List<Float>): Float {
        val s = v.sorted()
        return s[s.size / 2]
    }

    private fun assemble(all: List<P>): List<Slot> {
        val ps = all.filter { it.r in 0.056f..0.115f }.sortedBy { it.y }
        val rows = ArrayList<MutableList<P>>()
        for (p in ps) {
            val last = rows.lastOrNull()
            if (last != null && Math.abs(p.y - last.map { it.y }.average().toFloat()) < 0.04f) last.add(p)
            else rows.add(mutableListOf(p))
        }
        // keep real seat rows only: 2+ seats spaced like seats, or one seat in the middle (host / big mic)
        val good = ArrayList<List<P>>()
        for (row in rows) {
            val sorted = row.sortedBy { it.x }
            val dedup = ArrayList<P>()
            for (p in sorted) {
                if (dedup.isNotEmpty() && p.x - dedup.last().x < 1.6f * p.r) continue
                dedup.add(p)
            }
            if (dedup.size >= 2) {
                val rm = median(dedup.map { it.r })
                if (minGap(dedup.map { it.x }) >= 2.1f * rm) good.add(dedup)
            } else if (dedup.size == 1 && dedup[0].r >= 0.064f && Math.abs(dedup[0].x - 0.5f) < 0.07f) {
                good.add(dedup)
            }
        }
        if (good.isEmpty()) return emptyList()

        val mins = ArrayList<Float>()
        for (row in good) if (row.size >= 3) mins.add(minGap(row.map { it.x }))
        var sGlobal = 0f
        if (mins.isNotEmpty()) sGlobal = median(mins)
        else {
            var g = 9f
            for (row in good) if (row.size >= 2) g = Math.min(g, minGap(row.map { it.x }))
            if (g < 9f) sGlobal = g
        }

        val out = ArrayList<Slot>()
        val singleTop = good.size > 1 && good[0].size == 1
        for ((ri, row) in good.withIndex()) {
            val y = row.map { it.y }.average().toFloat()
            val r = median(row.map { it.r })
            if (row.size == 1) {
                out.add(Slot(row[0].x, y, r, ri == 0 && singleTop))
                continue
            }
            val xs = row.map { it.x }
            val step = if (row.size >= 3) minGap(xs) else if (sGlobal > 0f) sGlobal else minGap(xs)
            val xL = xs.first()
            val xR = xs.last()
            val xL2 = Math.min(xL, 1f - xR)
            val xR2 = Math.max(xR, 1f - xL)
            val kk = Math.max(1, Math.round((xR2 - xL2) / step))
            val cnt = kk + 1
            var fits = cnt <= 8 && xL2 > r * 0.8f && xR2 < 1f - r * 0.8f
            if (fits) {
                val st = (xR2 - xL2) / kk
                for (x in xs) {
                    val q = (x - xL2) / st
                    if (Math.abs(q - Math.round(q)) > 0.3f) { fits = false; break }
                }
            }
            if (fits) {
                val st = (xR2 - xL2) / kk
                for (i in kk downTo 0) out.add(Slot(xL2 + i * st, y, r))      // right -> left
            } else {
                for (i in xs.indices.reversed()) out.add(Slot(xs[i], y, r))
            }
        }
        return if (out.size in 2..20) out else emptyList()
    }
}
