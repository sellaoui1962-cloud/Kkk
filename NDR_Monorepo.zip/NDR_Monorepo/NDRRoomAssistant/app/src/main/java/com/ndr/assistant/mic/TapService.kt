package com.ndr.assistant.mic

import android.os.IBinder
import android.os.SystemClock
import android.view.InputDevice
import android.view.InputEvent
import android.view.MotionEvent
import java.lang.reflect.Method

/**
 * Runs inside the Shizuku (shell) process, NOT inside the app: it pushes touch events straight into the
 * system input dispatcher. That skips the accessibility gesture pipeline, which is the slowest part of a tap.
 */
class TapService : ITapService.Stub() {
    private var imObj: Any? = null
    private var imInject: Method? = null
    private var mgrObj: Any? = null
    private var mgrInject: Method? = null

    init {
        try {
            val sm = Class.forName("android.os.ServiceManager")
            val binder = sm.getMethod("getService", String::class.java).invoke(null, "input") as IBinder
            val stub = Class.forName("android.hardware.input.IInputManager\$Stub")
            imObj = stub.getMethod("asInterface", IBinder::class.java).invoke(null, binder)
            // look the method up on the (public) interface, not on the private Stub.Proxy class
            imInject = Class.forName("android.hardware.input.IInputManager")
                .getMethod("injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType)
        } catch (_: Throwable) {
            imObj = null
            imInject = null
        }
        try {
            val cls = Class.forName("android.hardware.input.InputManager")
            mgrObj = cls.getMethod("getInstance").invoke(null)
            mgrInject = cls.getMethod("injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType)
        } catch (_: Throwable) {
            mgrObj = null
            mgrInject = null
        }
    }

    private fun inject(ev: InputEvent): Boolean {
        val a = imInject
        val ao = imObj
        if (a != null && ao != null) {
            try {
                val r = a.invoke(ao, ev, 0)
                return if (r is Boolean) r else true
            } catch (_: Throwable) {}
        }
        val b = mgrInject
        val bo = mgrObj
        if (b != null && bo != null) {
            try {
                val r = b.invoke(bo, ev, 0)
                return if (r is Boolean) r else true
            } catch (_: Throwable) {}
        }
        return false
    }

    private fun send(px: Float, py: Float, action: Int, downTime: Long): Boolean {
        val pp = MotionEvent.PointerProperties()
        pp.id = 0
        pp.toolType = MotionEvent.TOOL_TYPE_FINGER
        val pc = MotionEvent.PointerCoords()
        pc.x = px
        pc.y = py
        pc.pressure = 1f
        pc.size = 1f
        val ev = MotionEvent.obtain(
            downTime, SystemClock.uptimeMillis(), action, 1,
            arrayOf(pp), arrayOf(pc), 0, 0, 1f, 1f, 0, 0, InputDevice.SOURCE_TOUCHSCREEN, 0
        )
        try {
            return inject(ev)
        } finally {
            ev.recycle()
        }
    }

    private fun oneTap(x: Float, y: Float): Boolean {
        val down = SystemClock.uptimeMillis()
        if (!send(x, y, MotionEvent.ACTION_DOWN, down)) return false
        return send(x, y, MotionEvent.ACTION_UP, down)
    }

    override fun tap(x: Float, y: Float, twice: Boolean): Boolean {
        val ok = oneTap(x, y)
        if (ok && twice) {
            Thread {
                try {
                    Thread.sleep(60)
                    oneTap(x, y)
                } catch (_: Throwable) {}
            }.start()
        }
        return ok
    }

    override fun ping(): Boolean = imInject != null || mgrInject != null

    override fun destroy() {
        System.exit(0)
    }
}
