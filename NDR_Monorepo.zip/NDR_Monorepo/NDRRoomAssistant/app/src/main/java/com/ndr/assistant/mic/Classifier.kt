package com.ndr.assistant.mic

import java.nio.ByteBuffer

/**
 * One captured frame, copied once into a plain byte array (a single bulk copy) so every pixel read
 * afterwards is a cheap array access instead of a ByteBuffer call with bounds checks.
 */
class Frame(val w: Int, val h: Int) {
    @JvmField var data = ByteArray(0)
    @JvmField var rs = 0
    @JvmField var ps = 4

    fun load(buf: java.nio.ByteBuffer, rowStride: Int, pixelStride: Int) {
        rs = rowStride
        ps = pixelStride
        val need = Math.min(buf.remaining(), rowStride * h)
        if (data.size < need) data = ByteArray(need)
        buf.get(data, 0, need)
    }

    /** Copies another frame into this one (reuses the same array: no allocation per background job). */
    fun copyFrom(o: Frame) {
        rs = o.rs
        ps = o.ps
        if (data.size < o.data.size) data = ByteArray(o.data.size)
        System.arraycopy(o.data, 0, data, 0, o.data.size)
    }

    fun rgb(x: Int, y: Int): Int {
        val xx = if (x < 0) 0 else if (x >= w) w - 1 else x
        val yy = if (y < 0) 0 else if (y >= h) h - 1 else y
        val o = yy * rs + xx * ps
        val d = data
        return ((d[o].toInt() and 0xFF) shl 16) or ((d[o + 1].toInt() and 0xFF) shl 8) or (d[o + 2].toInt() and 0xFF)
    }

    fun lum(x: Int, y: Int): Float {
        val xx = if (x < 0) 0 else if (x >= w) w - 1 else x
        val yy = if (y < 0) 0 else if (y >= h) h - 1 else y
        val o = yy * rs + xx * ps
        val d = data
        return 0.299f * (d[o].toInt() and 0xFF) +
            0.587f * (d[o + 1].toInt() and 0xFF) +
            0.114f * (d[o + 2].toInt() and 0xFF)
    }
}

object Classifier {
    const val LOCKED = 0
    const val EMPTY = 1
    const val OCC = 2
    const val UNK = 3

    private const val G = 16
    private val tl = Templates.tl
    private val te = Templates.te
    // scratch buffers: the capture thread (quick / classify) and the fitting worker (best) must not share them
    private val tmp = FloatArray(G * G)
    private val sc = FloatArray(2)
    private val tmpW = FloatArray(G * G)
    private val scW = FloatArray(2)

    /** Set by quick() / classify(): was there a strong (>= 0.8) icon match, and the best raw score. */
    /** deep = every sample is the average of a 3x3 pixel block (pixel-by-pixel analysis); turbo = lower thresholds. */
    @JvmField var deep = true
    @JvmField var turbo = true
    @JvmField var lastStrong = false
    @JvmField var lastMax = 0f

    /** Normalized correlation with the lock and mic templates. */
    private fun score(f: Frame, cx: Float, cy: Float, r: Float, out: FloatArray, blocks: Boolean, tmp: FloatArray = this.tmp) {
        val step = 2f * Templates.SPAN * r / (G - 1)
        val sub = step / 3f
        var k = 0
        var sum = 0f
        for (j in 0 until G) {
            val yc = cy + (j - (G - 1) / 2f) * step
            for (i in 0 until G) {
                val xc = cx + (i - (G - 1) / 2f) * step
                val v: Float
                if (blocks) {
                    var a = 0f
                    for (dj in -1..1) {
                        val yy = Math.round(yc + dj * sub)
                        for (di in -1..1) a += f.lum(Math.round(xc + di * sub), yy)
                    }
                    v = a / 9f
                } else {
                    v = f.lum(Math.round(xc), Math.round(yc))
                }
                tmp[k++] = v
                sum += v
            }
        }
        val mean = sum / (G * G)
        var nn = 0f
        var dl = 0f
        var de = 0f
        for (q in 0 until G * G) {
            val v = tmp[q] - mean
            nn += v * v
            dl += v * tl[q]
            de += v * te[q]
        }
        if (nn < 1e-3f) { out[0] = 0f; out[1] = 0f; return }
        val inv = 1f / Math.sqrt(nn.toDouble()).toFloat()
        out[0] = dl * inv
        out[1] = de * inv
    }

    private fun decide(a: Float, b: Float): Int {
        val m = if (a > b) a else b
        val hi = if (turbo) 0.5f else 0.6f
        val mg = if (turbo) 0.12f else 0.2f
        val lo = if (turbo) 0.4f else 0.5f
        return when {
            a >= hi && a - b >= mg -> LOCKED
            b >= hi && b - a >= mg -> EMPTY
            m < lo -> OCC
            else -> UNK
        }
    }

    /** Best icon score (lock or mic) at exactly this spot. Used by layout calibration / auto-detect. */
    fun best(f: Frame, cx: Float, cy: Float, r: Float): Float {
        // worker thread only (layout fitting): has its own scratch buffers
        score(f, cx, cy, r, scW, false, tmpW)
        return if (scW[0] > scW[1]) scW[0] else scW[1]
    }

    /** One single scoring at the cached alignment: the cheap per-frame path. */
    fun quick(f: Frame, cx: Float, cy: Float, r: Float, off: IntArray): Int {
        score(f, cx + off[0], cy + off[1], r, sc, deep)
        val m = if (sc[0] > sc[1]) sc[0] else sc[1]
        lastMax = m
        lastStrong = m >= 0.8f
        return decide(sc[0], sc[1])
    }

    /** off = cached alignment offset (frame pixels), refined in place when a strong match is found. */
    fun classify(f: Frame, cx: Float, cy: Float, r: Float, off: IntArray): Int {
        score(f, cx + off[0], cy + off[1], r, sc, deep)
        var bm = if (sc[0] > sc[1]) sc[0] else sc[1]
        if (bm >= 0.8f) { lastMax = bm; lastStrong = true; return decide(sc[0], sc[1]) }
        var ba = sc[0]
        var bb = sc[1]
        var bx = off[0]
        var by = off[1]
        val ox = off[0]
        val oy = off[1]
        var dy = -4
        while (dy <= 4) {
            var dx = -4
            while (dx <= 4) {
                score(f, cx + ox + dx, cy + oy + dy, r, sc, deep)
                val m = if (sc[0] > sc[1]) sc[0] else sc[1]
                if (m > bm) { bm = m; ba = sc[0]; bb = sc[1]; bx = ox + dx; by = oy + dy }
                dx += 2
            }
            dy += 2
        }
        val cx0 = bx
        val cy0 = by
        for (ddy in -1..1) {
            for (ddx in -1..1) {
                if (ddx == 0 && ddy == 0) continue
                score(f, cx + cx0 + ddx, cy + cy0 + ddy, r, sc, deep)
                val m = if (sc[0] > sc[1]) sc[0] else sc[1]
                if (m > bm) { bm = m; ba = sc[0]; bb = sc[1]; bx = cx0 + ddx; by = cy0 + ddy }
            }
        }
        lastMax = bm
        lastStrong = bm >= 0.8f
        if (lastStrong) {
            off[0] = bx.coerceIn(-10, 10)
            off[1] = by.coerceIn(-10, 10)
        }
        return decide(ba, bb)
    }
}

/** Avatar fingerprint (8x8 colour grid inside the seat) used by the Magnet to recognise a person. */
object Sig {
    private const val N = 8

    fun of(f: Frame, cx: Float, cy: Float, r: Float): IntArray {
        val out = IntArray(N * N)
        val half = 0.62f * r
        val cell = 2f * half / N
        for (gy in 0 until N) {
            for (gx in 0 until N) {
                val x0 = cx - half + gx * cell
                val y0 = cy - half + gy * cell
                var sr = 0
                var sg = 0
                var sb = 0
                for (j in 0 until 3) {
                    for (i in 0 until 3) {
                        val px = Math.round(x0 + cell * (i + 0.5f) / 3f)
                        val py = Math.round(y0 + cell * (j + 0.5f) / 3f)
                        val v = f.rgb(px, py)
                        sr += (v shr 16) and 255
                        sg += (v shr 8) and 255
                        sb += v and 255
                    }
                }
                out[gy * N + gx] = ((sr / 9) shl 16) or ((sg / 9) shl 8) or (sb / 9)
            }
        }
        return out
    }

    /** Share of matching cells (the centre is skipped: mute / speaking icons sit there). */
    fun sim(a: IntArray, b: IntArray): Float {
        var ok = 0
        var tot = 0
        for (q in 0 until N * N) {
            val gy = q / N
            val gx = q % N
            if (gy in 3..4 && gx in 3..4) continue
            tot++
            val dr = Math.abs(((a[q] shr 16) and 255) - ((b[q] shr 16) and 255))
            val dg = Math.abs(((a[q] shr 8) and 255) - ((b[q] shr 8) and 255))
            val db = Math.abs((a[q] and 255) - (b[q] and 255))
            if (dr + dg + db < 90) ok++
        }
        return ok.toFloat() / tot
    }

    /** Best similarity against the reference, tolerating a few pixels of misalignment. */
    fun match(f: Frame, cx: Float, cy: Float, r: Float, ref: IntArray): Float {
        var best = 0f
        val sh = intArrayOf(0, -4, 4)
        for (dy in sh) {
            for (dx in sh) {
                val v = sim(of(f, cx + dx, cy + dy, r), ref)
                if (v > best) best = v
                if (best >= 0.92f) return best
            }
        }
        return best
    }
}
