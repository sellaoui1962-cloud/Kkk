package com.ndr.assistant.mic

import com.ndr.assistant.R

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.util.TypedValue
import android.widget.TextView

/** NMic Pro look: pure black and white, flat rectangles only, heavy geometric type. */
object UiKit {
    val BG = 0xFF08080A.toInt()
    val CARD = 0xFF101013.toInt()
    val CHIP = 0xFF18181C.toInt()
    val STROKE = 0xFF2E2E34.toInt()
    val ACCENT = 0xFFFFFFFF.toInt()
    val ACCENT_DIM = 0xFF212126.toInt()
    val ON_ACCENT = 0xFF08080A.toInt()
    val TEXT = 0xFFF2F2F4.toInt()
    val MUTED = 0xFF8E8E96.toInt()

    // status colours (the only colour in the app, so they always read at a glance)
    val DANGER = 0xFFE5484D.toInt()   // locked
    val OPEN = 0xFF30D67B.toInt()     // open mic
    val BLUE = 0xFFFFFFFF.toInt()     // taken
    val YELLOW = 0xFFF5A524.toInt()   // unsure

    private var face: Typeface? = null

    fun font(c: Context): Typeface {
        val f = face
        if (f != null) return f
        val t: Typeface = try { c.resources.getFont(R.font.nm_font) } catch (e: Exception) { Typeface.DEFAULT_BOLD }
        face = t
        return t
    }

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density + 0.5f).toInt()

    /** Always a sharp rectangle: the radius argument is kept only so old call sites stay valid. */
    fun bg(c: Context, color: Int, rDp: Int = 0, stroke: Int = 0, strokeDp: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.RECTANGLE
        g.setColor(color)
        if (strokeDp > 0) g.setStroke(dp(c, strokeDp), stroke)
        return g
    }

    fun pressable(normal: Drawable, pressed: Drawable): StateListDrawable {
        val s = StateListDrawable()
        s.addState(intArrayOf(android.R.attr.state_pressed), pressed)
        s.addState(intArrayOf(), normal)
        return s
    }

    fun tv(c: Context, text: String, sp: Float, color: Int, bold: Boolean = false, mono: Boolean = false): TextView {
        val t = TextView(c)
        t.text = text
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        t.setTextColor(color)
        t.typeface = font(c)
        return t
    }

    val HAIR = 0xFF3A3A42.toInt()

    /** Small caps style section label (letter spacing only for Latin: it would break Arabic joining). */
    fun label(c: Context, text: String, color: Int): TextView {
        val t = tv(c, if (Loc.isAr()) text else text.uppercase(), 12f, color, true)
        if (!Loc.isAr()) t.letterSpacing = 0.12f
        return t
    }
}
