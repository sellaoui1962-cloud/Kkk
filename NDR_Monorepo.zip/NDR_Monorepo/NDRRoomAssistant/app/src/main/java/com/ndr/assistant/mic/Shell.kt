package com.ndr.assistant.mic

import android.content.ComponentName
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import rikka.shizuku.Shizuku

/**
 * Optional Shizuku link. When Shizuku is running and the permission is granted, taps are injected from
 * the shell process (a few milliseconds) instead of going through the accessibility gesture pipeline.
 * If anything is missing, tap() returns false and the caller falls back to the accessibility tap.
 */
object Shell {
    private const val REQ = 4242

    @Volatile private var svc: ITapService? = null
    @Volatile private var binding = false
    @Volatile var on = true
    private var started = false

    /** Set by the main screen so the Shizuku status line refreshes itself. */
    @Volatile var onChange: (() -> Unit)? = null

    private val args: Shizuku.UserServiceArgs by lazy {
        Shizuku.UserServiceArgs(ComponentName(App.ctx.packageName, TapService::class.java.name))
            .daemon(false)
            .processNameSuffix("tap")
            .debuggable(false)
            .version(1)
    }

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, b: IBinder?) {
            binding = false
            if (b != null && b.pingBinder()) svc = ITapService.Stub.asInterface(b)
            notifyChange()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            svc = null
            binding = false
            notifyChange()
        }
    }

    private val binderListener = Shizuku.OnBinderReceivedListener {
        if (on) bind()
        notifyChange()
    }
    private val deadListener = Shizuku.OnBinderDeadListener {
        svc = null
        binding = false
        notifyChange()
    }
    private val permListener = Shizuku.OnRequestPermissionResultListener { _, result ->
        if (result == PackageManager.PERMISSION_GRANTED && on) bind()
        notifyChange()
    }

    private fun notifyChange() { onChange?.invoke() }

    fun init() {
        if (started) return
        started = true
        on = Prefs.shizuku
        try {
            Shizuku.addBinderReceivedListenerSticky(binderListener)
            Shizuku.addBinderDeadListener(deadListener)
            Shizuku.addRequestPermissionResultListener(permListener)
        } catch (_: Throwable) {}
    }

    fun running(): Boolean = try { Shizuku.pingBinder() } catch (_: Throwable) { false }

    fun granted(): Boolean = try {
        running() && !Shizuku.isPreV11() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) { false }

    /** True when taps are really going through Shizuku right now. */
    fun active(): Boolean = on && svc != null

    /** Turns the feature on: asks for the permission if needed, then connects. */
    fun enable() {
        Prefs.shizuku = true
        on = true
        init()
        try {
            if (running() && !Shizuku.isPreV11()) {
                if (granted()) bind() else Shizuku.requestPermission(REQ)
            }
        } catch (_: Throwable) {}
        notifyChange()
    }

    fun disable() {
        Prefs.shizuku = false
        on = false
        unbind()
        notifyChange()
    }

    private fun bind() {
        if (svc != null || binding) return
        try {
            if (!granted()) return
            binding = true
            Shizuku.bindUserService(args, conn)
        } catch (_: Throwable) {
            binding = false
        }
    }

    private fun unbind() {
        try { Shizuku.unbindUserService(args, conn, true) } catch (_: Throwable) {}
        svc = null
        binding = false
    }

    /** Returns true if the tap was injected through Shizuku. */
    fun tap(x: Float, y: Float, twice: Boolean): Boolean {
        if (!on) return false
        val s = svc ?: return false
        return try {
            s.tap(x, y, twice)
        } catch (_: Throwable) {
            svc = null
            false
        }
    }
}
