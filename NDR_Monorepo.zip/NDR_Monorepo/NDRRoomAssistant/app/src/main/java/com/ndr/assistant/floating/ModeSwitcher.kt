package com.ndr.assistant.floating

import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.ndr.assistant.R
import com.ndr.assistant.core.AssistMode
import com.ndr.assistant.core.ModeState
import com.ndr.assistant.mic.NdrService
import com.ndr.assistant.mic.UiKit

/**
 * The single floating control of NDR Room Assistant.
 *  - collapsed: small draggable "N" icon (tap = expand, long-press = hide)
 *  - expanded : two big buttons [ MIC ] [ TAG ] + settings / minimize / close-panel
 * It only flips ModeState via NdrService.switchMode(); it owns no engine and no capture session.
 */
class ModeSwitcher(private val svc: NdrService) {
    private val wm = svc.getSystemService(android.content.Context.WINDOW_SERVICE) as WindowManager
    private val slop = ViewConfiguration.get(svc).scaledTouchSlop
    private var root: FrameLayout? = null
    private var lp: WindowManager.LayoutParams? = null
    private var expanded = false

    private var icon: TextView? = null
    private var panel: LinearLayout? = null
    private var micBtn: TextView? = null
    private var tagBtn: TextView? = null
    private var indicator: TextView? = null

    private fun d(v: Int) = UiKit.dp(svc, v)
    private fun modeColor(m: AssistMode) = if (m == AssistMode.MIC) UiKit.OPEN else UiKit.YELLOW

    val isShown: Boolean get() = root != null

    fun show() {
        if (root != null) return
        val r = FrameLayout(svc)
        val l = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        l.gravity = Gravity.TOP or Gravity.START
        l.x = d(8); l.y = d(180)
        root = r; lp = l
        buildIcon(); buildPanel()
        r.addView(icon); r.addView(panel)
        applyState()
        try { wm.addView(r, l) } catch (_: Exception) { root = null; lp = null }
    }

    fun hide() {
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        root = null; lp = null; icon = null; panel = null; micBtn = null; tagBtn = null; indicator = null
        expanded = false
    }

    fun destroy() = hide()

    /** Re-style for the current mode (called by NdrService after every switch). */
    fun refresh() { if (root != null) applyState() }

    fun collapse() { expanded = false; applyState() }

    // ------------------------------------------------------------------ views
    private fun ovalBg(color: Int, stroke: Int): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.OVAL; setColor(color); setStroke(d(2), stroke)
    }

    private fun buildIcon() {
        val t = TextView(svc)
        t.text = "N"
        t.gravity = Gravity.CENTER
        t.setTextColor(Color.WHITE)
        t.textSize = 18f
        t.setTypeface(Typeface.DEFAULT_BOLD)
        t.layoutParams = FrameLayout.LayoutParams(d(46), d(46))
        dragOrClick(t, onClick = { expanded = true; applyState() }, onLong = { hide(); toast("NDR hidden - show it again from the app") })
        icon = t
    }

    private fun buildPanel() {
        val p = LinearLayout(svc)
        p.orientation = LinearLayout.VERTICAL
        p.setPadding(d(8), d(6), d(8), d(8))
        p.background = UiKit.bg(svc, 0xF208080A.toInt(), 0, UiKit.STROKE, 1)

        // header (drag handle + settings / minimize / close mode)
        val head = LinearLayout(svc)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val title = UiKit.tv(svc, "NDR", 13f, UiKit.TEXT, true)
        title.setPadding(d(4), d(4), d(12), d(4))
        dragOrClick(title, onClick = {}, onLong = {})
        head.addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(small("\u2699") { openSettings() })
        head.addView(small("\u2013") { collapse() })
        head.addView(small("\u2715") { svc.closeActivePanel(); collapse() })
        p.addView(head)

        // the two big mode buttons
        val row = LinearLayout(svc)
        row.orientation = LinearLayout.HORIZONTAL
        val m = big(svc.getString(R.string.mode_mic)) { svc.switchMode(AssistMode.MIC); collapse() }
        val g = big(svc.getString(R.string.mode_tag)) { svc.switchMode(AssistMode.TAG); collapse() }
        val lm = LinearLayout.LayoutParams(d(96), d(52)); lm.marginEnd = d(6)
        row.addView(m, lm); row.addView(g, LinearLayout.LayoutParams(d(96), d(52)))
        p.addView(row)
        micBtn = m; tagBtn = g

        val ind = UiKit.tv(svc, "", 11f, UiKit.MUTED)
        ind.setPadding(d(2), d(6), 0, 0)
        p.addView(ind)
        indicator = ind
        panel = p
    }

    private fun small(label: String, onClick: () -> Unit): TextView {
        val t = UiKit.tv(svc, label, 15f, UiKit.TEXT, true)
        t.gravity = Gravity.CENTER
        t.minWidth = d(34); t.setPadding(d(6), d(4), d(6), d(4))
        t.setOnClickListener { onClick() }
        return t
    }

    private fun big(label: String, onClick: () -> Unit): TextView {
        val t = UiKit.tv(svc, label, 18f, UiKit.TEXT, true)
        t.gravity = Gravity.CENTER
        t.setOnClickListener { onClick() }
        return t
    }

    private fun applyState() {
        val m = ModeState.mode.value
        val col = modeColor(m)
        icon?.background = ovalBg(0xF208080A.toInt(), col)
        icon?.visibility = if (expanded) View.GONE else View.VISIBLE
        panel?.visibility = if (expanded) View.VISIBLE else View.GONE
        fun style(b: TextView?, on: Boolean, c: Int, enabled: Boolean) {
            b ?: return
            b.setTextColor(if (on) UiKit.ON_ACCENT else UiKit.TEXT)
            b.background = if (on) UiKit.bg(svc, c, 0, c, 1) else UiKit.bg(svc, UiKit.CHIP, 0, UiKit.STROKE, 1)
            b.alpha = if (enabled) 1f else 0.4f
        }
        style(micBtn, m == AssistMode.MIC, modeColor(AssistMode.MIC), true)
        style(tagBtn, m == AssistMode.TAG, modeColor(AssistMode.TAG), ModeState.tagSupported)
        indicator?.text = "\u25CF " + (if (m == AssistMode.MIC) svc.getString(R.string.mode_mic) else svc.getString(R.string.mode_tag))
        indicator?.setTextColor(col)
        try { root?.let { wm.updateViewLayout(it, lp) } } catch (_: Exception) {}
    }

    // ------------------------------------------------------------------ behaviour
    private fun openSettings() {
        val cls = if (ModeState.mode.value == AssistMode.TAG)
            com.ndr.assistant.tag.ui.MainActivity::class.java else com.ndr.assistant.mic.MainActivity::class.java
        try {
            svc.startActivity(Intent(svc, cls).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) { toast("Open the NDR app from the launcher") }
    }

    private fun toast(s: String) = Toast.makeText(svc, s, Toast.LENGTH_SHORT).show()

    /** One touch listener: drag moves the window, a still tap clicks, a still hold long-presses. */
    private fun dragOrClick(v: View, onClick: () -> Unit, onLong: () -> Unit) {
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        var moved = false; var downAt = 0L
        v.setOnTouchListener { _, e ->
            val l = lp ?: return@setOnTouchListener true
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = l.x; oy = l.y; moved = false; downAt = e.eventTime }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (!moved && (Math.abs(dx) > slop || Math.abs(dy) > slop)) moved = true
                    if (moved) {
                        l.x = ox + dx.toInt(); l.y = oy + dy.toInt()
                        try { root?.let { wm.updateViewLayout(it, l) } } catch (_: Exception) {}
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) {
                    if (e.eventTime - downAt >= ViewConfiguration.getLongPressTimeout()) onLong() else onClick()
                }
            }
            true
        }
    }
}
