package com.ndr.assistant.tag.core

/**
 * اللعبة ترفض الرسالة المطابقة لسابقتها، لذلك نضيف دائمًا بعد المنشن مسافة ونقطة،
 * ونبدّل بين نقطة ونقطتين: " ." ثم " .." ثم " ." ثم " .." ...
 * (المنشن نفسه يضيفه زر @ في اللعبة، فيبقى معرّف اللاعب الحقيقي سليمًا.)
 */
class MentionHistory {
    private var two = false
    fun nextSuffix(): String = if (two) " .." else " ."
    /** بعد إرسال مؤكَّد. */
    fun commit() { two = !two }
    /** رُفضت الرسالة (غالبًا تطابق): جرّب الصيغة الأخرى في المرة القادمة. */
    fun markRejected() { two = !two }
    fun reset() { two = false }
}
