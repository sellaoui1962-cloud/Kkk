package com.ndr.assistant.mic

import com.ndr.assistant.R

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.ndr.assistant.core.AssistMode
import com.ndr.assistant.core.ModeState
import com.ndr.assistant.floating.ModeSwitcher
import com.ndr.assistant.tag.service.TagController

/**
 * Accessibility service: injects the taps and hosts all floating UI
 * (control panel, number pad / magnet pad, detection frames, layout editor).
 */
class NdrService : AccessibilityService() {
    companion object {
        @Volatile var instance: NdrService? = null
    }

    private val main = Handler(Looper.getMainLooper())

    // --- unified assistant: ONE accessibility service hosts the MIC panel, the TAG engine and the switcher
    private var tagCtl: TagController? = null
    private var switcher: ModeSwitcher? = null
    private lateinit var wm: WindowManager
    private var lc: Context? = null

    @Volatile var panelVisible = false
        private set
    private var collapsed = false

    private var panel: View? = null
    private var pad: View? = null
    private var padKey = ""
    private var dots: DotsView? = null
    private var editor: View? = null

    private val chips = arrayOfNulls<View>(5)
    private var startBtn: TextView? = null
    private var focusBtn: TextView? = null
    private var dotsBtn: TextView? = null
    private var nudgeRow: View? = null
    private var status: TextView? = null
    private var led: View? = null
    private var body: View? = null

    // magnet pad
    private var padCells = arrayOfNulls<TextView>(0)
    private var padInfo: TextView? = null
    private var shownT = -2
    private var shownMe = -2
    private var shownPh = -2

    private val dotsLoop = object : Runnable {
        override fun run() {
            val d = dots ?: return
            d.invalidate()
            main.postDelayed(this, 120)
        }
    }

    private val uiLoop = object : Runnable {
        override fun run() {
            if (!panelVisible || Engine.mode != Engine.MAGNET) return
            updatePadMarks()
            main.postDelayed(this, 150)
        }
    }

    // ---------------------------------------------------------------- lifecycle
    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        Engine.load()
        Engine.onStatus = { msg -> main.post { status?.text = msg; status?.setTextColor(UiKit.ACCENT) } }
        if (ModeState.tagSupported && tagCtl == null) tagCtl = TagController(this).also { it.start() }
        if (switcher == null) switcher = ModeSwitcher(this)
        switcher?.show()
    }

    // ---------------------------------------------------------------- mode switching (MIC <-> TAG)
    /** Instant switch: no restart, no re-created listeners. Only the active mode keeps processing. */
    fun switchMode(m: AssistMode) {
        main.post {
            if (m == AssistMode.TAG && (!ModeState.tagSupported || tagCtl == null)) {
                Toast.makeText(this, R.string.sw_tag_old, Toast.LENGTH_SHORT).show()
                return@post
            }
            ModeState.mode.value = m
            when (m) {
                AssistMode.MIC -> {
                    tagCtl?.setActive(false)
                    Engine.paused = false
                    if (panelVisible) refreshUi() else showPanel()
                }
                AssistMode.TAG -> {
                    Engine.paused = true          // stop MIC frame processing, capture session stays alive
                    if (panelVisible) tearDown()  // also disarms the engine
                    tagCtl?.setActive(true)
                }
            }
            switcher?.refresh()
        }
    }

    /** The close button of the switcher: stop whatever the active mode is showing. */
    fun closeActivePanel() {
        main.post {
            if (ModeState.mode.value == AssistMode.TAG) tagCtl?.setActive(false) else tearDown()
        }
    }

    fun showSwitcher() { main.post { switcher?.show() } }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (ModeState.mode.value == AssistMode.TAG) tagCtl?.onEvent(event)   // nothing runs for the inactive mode
    }
    override fun onInterrupt() { tagCtl?.onInterrupt() }

    override fun onUnbind(intent: Intent?): Boolean {
        shutdownAll()
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        shutdownAll()
        instance = null
        super.onDestroy()
    }

    private fun shutdownAll() {
        tearDown()
        tagCtl?.stop(); tagCtl = null
        switcher?.destroy(); switcher = null
    }

    private fun tearDown() {
        Engine.armed = false
        main.removeCallbacks(uiLoop)
        removeView(panel); panel = null
        removePad(); removeDots(); removeEditor()
        panelVisible = false
    }

    // ---------------------------------------------------------------- tapping
    fun tap(x: Float, y: Float, twice: Boolean) {
        // fastest path first: Shizuku injects the touch straight into the input system
        if (Shell.tap(x, y, twice)) return
        val path = Path()
        path.moveTo(x, y)
        val b = GestureDescription.Builder()
        b.addStroke(GestureDescription.StrokeDescription(path, 0, 5))
        if (twice) {
            val p2 = Path()
            p2.moveTo(x, y)
            b.addStroke(GestureDescription.StrokeDescription(p2, 60, 5))
        }
        dispatchGesture(b.build(), null, null)
    }

    // ---------------------------------------------------------------- public API
    fun showPanel() {
        main.post {
            if (panelVisible) { refreshUi(); return@post }
            lc = Loc.wrap(this)
            Engine.load()
            buildPanel()
            panelVisible = true
            refreshUi()
        }
    }

    fun hidePanel() {
        main.post {
            tearDown()
        }
    }

    /** Called when settings, capture state or layout changed. */
    fun refreshUi() {
        main.post {
            if (!panelVisible) return@post
            val c = lc ?: return@post
            val isPad = Engine.mode == Engine.PAD
            val isMag = Engine.mode == Engine.MAGNET
            for (i in 0..4) chips[i]?.let { styleChip(it, i == Engine.mode) }
            val armed = Engine.armed && !isPad
            startBtn?.visibility = if (isPad) View.GONE else View.VISIBLE
            startBtn?.text = c.getString(if (armed) R.string.p_stop else R.string.p_start)
            startBtn?.background = UiKit.bg(c, if (armed) UiKit.DANGER else UiKit.ACCENT)
            startBtn?.setTextColor(if (armed) Color.WHITE else UiKit.ON_ACCENT)
            led?.background = rectBg(if (armed || isPad) UiKit.OPEN else 0xFF5A5A5A.toInt())
            val needCap = !isPad && !Engine.capturing
            status?.text = when {
                needCap -> c.getString(R.string.p_nocap)
                armed -> c.getString(R.string.p_armed)
                isPad -> ""
                else -> c.getString(R.string.p_idle)
            }
            status?.setTextColor(if (needCap) UiKit.DANGER else UiKit.MUTED)
            status?.visibility = if (isPad) View.GONE else View.VISIBLE
            dotsBtn?.let { styleChip(it, Prefs.dots) }
            focusBtn?.let {
                val fo = Engine.focus
                it.text = when {
                    fo >= 0 -> c.getString(R.string.p_focus) + " #" + (fo + 1) + " ✕"
                    Engine.focusPick -> c.getString(R.string.p_focus) + " …"
                    else -> c.getString(R.string.p_focus)
                }
                styleChip(it, fo >= 0 || Engine.focusPick)
            }
            nudgeRow?.visibility = if (Prefs.dots && !isPad && Engine.currentId != "custom") View.VISIBLE else View.GONE
            if ((isPad || isMag || Engine.focusPick) && editor == null) showPad() else removePad()
            if (Prefs.dots && Engine.capturing && !isPad && editor == null) showDots() else removeDots()
            main.removeCallbacks(uiLoop)
            if (isMag) main.post(uiLoop)
        }
    }

    // ---------------------------------------------------------------- panel
    private fun d(v: Int) = UiKit.dp(this, v)

    private fun overlayLp(w: Int, h: Int, flags: Int): WindowManager.LayoutParams {
        val lp = WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, flags, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START
        return lp
    }

    private fun rectBg(color: Int): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.RECTANGLE
        g.setColor(color)
        return g
    }

    private fun styleChip(t: View, on: Boolean) {
        val c = lc ?: return
        if (t is TextView) t.setTextColor(if (on) UiKit.ON_ACCENT else UiKit.TEXT)
        if (t is MagnetView) t.setOn(on)
        t.background = if (on) UiKit.bg(c, UiKit.ACCENT, 0, UiKit.ACCENT, 1) else UiKit.bg(c, UiKit.CHIP, 0, UiKit.STROKE, 1)
    }

    private fun chip(text: String, onClick: () -> Unit): TextView {
        val c = lc!!
        val t = UiKit.tv(c, text, 12f, UiKit.TEXT, true)
        t.gravity = Gravity.CENTER
        t.setPadding(d(8), d(8), d(8), d(8))
        t.background = UiKit.bg(c, UiKit.CHIP, 0, UiKit.STROKE, 1)
        t.setOnClickListener { onClick() }
        return t
    }

    private fun smallBtn(text: String, onClick: () -> Unit): TextView {
        val t = chip(text, onClick)
        t.textSize = 14f
        t.minWidth = d(34)
        return t
    }

    private fun dragBy(handle: View, target: View, lp: WindowManager.LayoutParams) {
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = ox + (e.rawX - sx).toInt()
                    lp.y = oy + (e.rawY - sy).toInt()
                    try { wm.updateViewLayout(target, lp) } catch (_: Exception) {}
                }
            }
            true
        }
    }

    private fun dirFlag(): Int = if (Loc.isAr()) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR

    private fun buildPanel() {
        val c = lc!!
        val root = LinearLayout(c)
        root.orientation = LinearLayout.VERTICAL
        root.layoutDirection = dirFlag()
        root.background = UiKit.bg(c, 0xF208080A.toInt(), 0, UiKit.HAIR, 1)
        root.setPadding(d(8), d(6), d(8), d(8))
        root.minimumWidth = d(200)

        val head = LinearLayout(c)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(0, d(2), 0, d(6))
        val ledV = View(c)
        led = ledV
        val ledLp = LinearLayout.LayoutParams(d(10), d(10))
        ledLp.marginEnd = d(6)
        head.addView(ledV, ledLp)
        head.addView(UiKit.tv(c, c.getString(R.string.app_name) + " ⠿", 12f, UiKit.ACCENT, true),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(smallBtn("–") { toggleCollapse() })
        val xLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        xLp.marginStart = d(4)
        head.addView(smallBtn("✕") { closeAll() }, xLp)

        val bodyL = LinearLayout(c)
        bodyL.orientation = LinearLayout.VERTICAL

        // modes: row 1 = OPEN / FOLLOW / PAD ; row 2 = TAKE-OVER / MAGNET
        val names = arrayOf(c.getString(R.string.p_open), c.getString(R.string.p_follow), c.getString(R.string.p_pad),
            c.getString(R.string.p_watch), "")
        val m1 = LinearLayout(c)
        m1.orientation = LinearLayout.HORIZONTAL
        val m2 = LinearLayout(c)
        m2.orientation = LinearLayout.HORIZONTAL
        for (i in 0..4) {
            val t: View = if (i == 4) {
                val mv = MagnetView(c)
                mv.setPadding(d(6), d(6), d(6), d(6))
                mv.setOnClickListener { setMode(4) }
                mv
            } else chip(names[i]) { setMode(i) }
            chips[i] = t
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(d(2), d(2), d(2), d(2))
            if (i < 3) m1.addView(t, lp) else m2.addView(t, lp)
        }
        bodyL.addView(m1)
        bodyL.addView(m2)

        // FOCUS ("Rasd"): act on one chosen seat only, works with every mode; tap again to go back to all seats
        val m3 = LinearLayout(c)
        m3.orientation = LinearLayout.HORIZONTAL
        val fb = chip(c.getString(R.string.p_focus)) { onFocusTap() }
        focusBtn = fb
        val fbLp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 2f)
        fbLp.setMargins(d(2), d(2), d(2), d(2))
        m3.addView(fb, fbLp)
        val sc = chip("↻") { Engine.requestScan(); Toast.makeText(c, R.string.scan_start, Toast.LENGTH_SHORT).show() }
        val scLp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        scLp.setMargins(d(2), d(2), d(2), d(2))
        m3.addView(sc, scLp)
        bodyL.addView(m3)

        val act = LinearLayout(c)
        act.orientation = LinearLayout.HORIZONTAL
        act.gravity = Gravity.CENTER_VERTICAL
        act.setPadding(0, d(6), 0, d(4))
        val sb = UiKit.tv(c, "", 13f, UiKit.ON_ACCENT, true)
        sb.gravity = Gravity.CENTER
        sb.setPadding(d(10), d(8), d(10), d(8))
        sb.setOnClickListener { toggleArm() }
        startBtn = sb
        val sbLp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        sbLp.setMargins(d(2), 0, d(4), 0)
        act.addView(sb, sbLp)
        val db = smallBtn("◉") { Prefs.dots = !Prefs.dots; refreshUi() }
        dotsBtn = db
        act.addView(db)
        val eLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        eLp.marginStart = d(4)
        act.addView(smallBtn("✎") { startEditor() }, eLp)
        bodyL.addView(act)

        // fine-tune arrows (only visible while the frames are shown)
        val nr = LinearLayout(c)
        nr.orientation = LinearLayout.HORIZONTAL
        nr.setPadding(0, 0, 0, d(4))
        val up = smallBtn("▲") { Engine.nudge(-0.005f) }
        val dn = smallBtn("▼") { Engine.nudge(0.005f) }
        val l1 = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        l1.setMargins(d(2), 0, d(2), 0)
        val l2 = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        l2.setMargins(d(2), 0, d(2), 0)
        nr.addView(up, l1)
        nr.addView(dn, l2)
        nr.visibility = View.GONE
        nudgeRow = nr
        bodyL.addView(nr)

        val st = UiKit.tv(c, "", 11f, UiKit.MUTED, false)
        st.setOnClickListener { onStatusTap() }
        status = st
        bodyL.addView(st)

        body = bodyL
        root.addView(head)
        root.addView(bodyL)
        bodyL.visibility = if (collapsed) View.GONE else View.VISIBLE

        val lp = overlayLp(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        )
        lp.x = d(8)
        lp.y = (screenHeight() * 0.56f).toInt()
        dragBy(head, root, lp)
        wm.addView(root, lp)
        panel = root
    }

    private fun screenHeight(): Float {
        val m = resources.displayMetrics
        return Math.max(m.widthPixels, m.heightPixels).toFloat()
    }

    private fun toggleCollapse() {
        collapsed = !collapsed
        body?.visibility = if (collapsed) View.GONE else View.VISIBLE
    }

    private fun onFocusTap() {
        if (Engine.focus >= 0 || Engine.focusPick) Engine.clearFocus() else Engine.focusPick = true
        refreshUi()
    }

    private fun setMode(i: Int) {
        Prefs.mode = i
        Engine.mode = i
        Engine.armed = false
        refreshUi()
    }

    private fun toggleArm() {
        if (!Engine.capturing) { onStatusTap(); return }
        Engine.armed = !Engine.armed
        refreshUi()
    }

    private fun onStatusTap() {
        if (Engine.mode != Engine.PAD && !Engine.capturing) {
            val i = Intent(this, MainActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            i.putExtra("capture", true)
            try { startActivity(i) } catch (_: Exception) {
                Toast.makeText(lc ?: this, R.string.p_nocap, Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun closeAll() {
        stopService(Intent(this, CaptureService::class.java))
        Engine.capturing = false
        tearDown()
    }

    // ---------------------------------------------------------------- number pad / magnet pad
    private fun showPad() {
        val c = lc ?: return
        val sl = Engine.slots
        val n = sl.size
        if (n == 0) return
        val magnet = Engine.mode == Engine.MAGNET
        val rowSig = Layouts.rowsOf(sl).joinToString(",") { it.size.toString() }
        val key = "$n/$rowSig/${Prefs.padSize}/${Loc.lang()}/$magnet/${Engine.currentId}"
        if (pad != null && key == padKey) return
        removePad()
        padKey = key

        val rows = Layouts.rowsOf(sl)
        var cols = 1
        for (r in rows) if (r.size > cols) cols = r.size
        val cell = d(intArrayOf(36, 44, 52)[Prefs.padSize.coerceIn(0, 2)])

        val box = LinearLayout(c)
        box.orientation = LinearLayout.VERTICAL
        box.layoutDirection = View.LAYOUT_DIRECTION_RTL   // numbers run right -> left like the game
        box.background = UiKit.bg(c, 0xEE08080A.toInt(), 0, UiKit.HAIR, 1)
        box.setPadding(d(4), d(2), d(4), d(4))

        val handle = UiKit.tv(c, "⠿⠿⠿", 14f, UiKit.ACCENT, true)
        handle.gravity = Gravity.CENTER
        handle.setPadding(0, d(2), 0, d(2))
        box.addView(handle, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        padCells = arrayOfNulls<TextView>(n)
        padInfo = null
        shownT = -2; shownMe = -2; shownPh = -2

        if (magnet) {
            val info = UiKit.tv(c, "", 11f, UiKit.MUTED, false)
            info.gravity = Gravity.CENTER
            info.setPadding(0, d(2), 0, d(2))
            padInfo = info
            box.addView(info, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }

        for (r in rows) {
            val rowL = LinearLayout(c)
            rowL.orientation = LinearLayout.HORIZONTAL
            rowL.layoutDirection = View.LAYOUT_DIRECTION_RTL
            rowL.gravity = Gravity.CENTER_HORIZONTAL
            for (idx in r) {
                val b = UiKit.tv(c, (idx + 1).toString(), if (cell > d(44)) 18f else 15f, UiKit.TEXT, true)
                b.gravity = Gravity.CENTER
                b.background = UiKit.pressable(
                    UiKit.bg(c, UiKit.CARD, 0, UiKit.STROKE, 1),
                    UiKit.bg(c, UiKit.ACCENT, 0, UiKit.ACCENT, 2)
                )
                b.setOnTouchListener { v, e ->
                    when (e.actionMasked) {
                        MotionEvent.ACTION_DOWN -> {
                            if (Engine.focusPick) {
                                Engine.setFocus(idx)
                                refreshUi()
                            } else if (Engine.mode == Engine.MAGNET) {
                                Engine.mgPickTarget(idx)
                                updatePadMarks()
                            } else {
                                v.isPressed = true
                                Engine.tapSlot(idx)
                            }
                        }
                        MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.isPressed = false
                    }
                    true
                }
                padCells[idx] = b
                val lp = LinearLayout.LayoutParams(cell, cell)
                lp.setMargins(d(2), d(2), d(2), d(2))
                rowL.addView(b, lp)
            }
            box.addView(rowL, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }

        val lp = overlayLp(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        )
        val padW = cols * (cell + d(4)) + d(8)
        val padH = rows.size * (cell + d(4)) + d(if (magnet) 44 else 24)
        lp.x = (Engine.screenW - padW - d(8)).toInt().coerceAtLeast(0)
        lp.y = (screenHeight() * 0.93f - padH).toInt().coerceAtLeast(0)
        dragBy(handle, box, lp)
        wm.addView(box, lp)
        pad = box
        if (magnet) updatePadMarks()
    }

    /** Highlights the chosen target / my seat and shows the magnet state. */
    private fun updatePadMarks() {
        val c = lc ?: return
        val t = Engine.mgTarget
        val me = Engine.mgMe
        val ph = Engine.mgPhase
        if (t == shownT && me == shownMe && ph == shownPh) return
        shownT = t; shownMe = me; shownPh = ph
        for (i in padCells.indices) {
            val v = padCells[i] ?: continue
            val isT = i == t
            val isMe = i == me
            v.background = when {
                isT -> UiKit.bg(c, UiKit.ACCENT, 0, UiKit.ACCENT, 2)
                isMe -> UiKit.bg(c, UiKit.ACCENT_DIM, 0, UiKit.ACCENT, 4)
                else -> UiKit.bg(c, UiKit.CARD, 0, UiKit.STROKE, 1)
            }
            v.setTextColor(if (isT) UiKit.ON_ACCENT else UiKit.TEXT)
        }
        val tt = if (t >= 0) "#" + (t + 1) else "–"
        val mm = if (me >= 0) "#" + (me + 1) else "–"
        val arrow = if (t < 0) "" else if (ph == 0) "  ▲" else "  ▼"
        padInfo?.text = c.getString(R.string.mg_target) + " " + tt + "   " + c.getString(R.string.mg_me) + " " + mm + arrow
    }

    private fun removePad() {
        removeView(pad)
        pad = null
        padKey = ""
        padInfo = null
        padCells = arrayOfNulls<TextView>(0)
    }

    // ---------------------------------------------------------------- dots
    private fun showDots() {
        if (dots != null) return
        val c = lc ?: return
        val v = DotsView(c)
        val lp = overlayLp(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        )
        wm.addView(v, lp)
        dots = v
        main.postDelayed(dotsLoop, 120)
    }

    private fun removeDots() {
        main.removeCallbacks(dotsLoop)
        removeView(dots)
        dots = null
    }

    // ---------------------------------------------------------------- editor
    private fun startEditor() {
        if (editor != null) return
        val c = lc ?: return
        removePad(); removeDots()
        val v = EditorView(c, onDone = { list ->
            if (list.isEmpty()) {
                Toast.makeText(c, R.string.ed_need, Toast.LENGTH_SHORT).show()
            } else {
                Prefs.custom = Layouts.serialize(list)
                Prefs.layoutId = "custom"
                Engine.load()
                Toast.makeText(c, R.string.ed_saved, Toast.LENGTH_SHORT).show()
                removeEditor()
                refreshUi()
            }
        }, onCancel = {
            removeEditor()
            refreshUi()
        })
        v.layoutDirection = dirFlag()
        val lp = overlayLp(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        )
        wm.addView(v, lp)
        editor = v
    }

    private fun removeEditor() {
        removeView(editor)
        editor = null
    }

    private fun removeView(v: View?) {
        if (v == null) return
        try { wm.removeView(v) } catch (_: Exception) {}
    }
}
