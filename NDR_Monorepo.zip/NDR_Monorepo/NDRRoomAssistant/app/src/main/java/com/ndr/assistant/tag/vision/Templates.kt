package com.ndr.assistant.tag.vision

import com.ndr.assistant.R

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.ndr.assistant.tag.R

/** إطار شاشة مصغّر (عرض 720) مع مصفوفة البكسلات. */
class Frame(val w: Int, val h: Int, val pix: IntArray, val bmp: Bitmap) {
    val f: Float get() = w / 1080f      // نسبة التصغير عن لقطة 1080 التي أُخذت منها القوالب
    fun lum(x: Int, y: Int): Int {
        if (x < 0 || y < 0 || x >= w || y >= h) return 0
        val p = pix[y * w + x]
        return (((p shr 16) and 255) * 299 + ((p shr 8) and 255) * 587 + (p and 255) * 114) / 1000
    }
}

class Sampled(val w: Int, val h: Int, val sx: IntArray, val sy: IntArray, val sv: IntArray)
data class Match(val x: Int, val y: Int, val w: Int, val h: Int, val score: Float) {
    val cx get() = x + w / 2
    val cy get() = y + h / 2
}

/** قوالب أيقونات اللعبة (ثابتة الشكل): الساعة الرملية، زر @، زر الإرسال الأخضر. */
class TemplateSet(ctx: Context) {
    private val res = ctx.resources
    private val raw = mapOf(
        "hourglass" to BitmapFactory.decodeResource(res, R.drawable.tpl_hourglass),
        "at" to BitmapFactory.decodeResource(res, R.drawable.tpl_at),
        "send" to BitmapFactory.decodeResource(res, R.drawable.tpl_send)
    )
    private val cache = HashMap<String, Sampled>()

    fun get(name: String, scale: Float): Sampled = cache.getOrPut("$name@${(scale * 100).toInt()}") {
        val src = raw.getValue(name)
        val w = (src.width * scale).toInt().coerceAtLeast(6); val h = (src.height * scale).toInt().coerceAtLeast(6)
        val b = Bitmap.createScaledBitmap(src, w, h, true)
        val xs = ArrayList<Int>(); val ys = ArrayList<Int>(); val vs = ArrayList<Int>()
        var y = 0
        while (y < h) { var x = 0; while (x < w) { xs += x; ys += y; vs += b.getPixel(x, y); x += 3 }; y += 3 }
        b.recycle()
        Sampled(w, h, xs.toIntArray(), ys.toIntArray(), vs.toIntArray())
    }
}

object Matcher {
    /** أفضل تطابق (متوسط فرق RGB مُطبَّع 0..1، الأقل أفضل) داخل المنطقة، أو null إن تجاوز maxScore. */
    fun find(fr: Frame, t: Sampled, x0: Int, y0: Int, x1: Int, y1: Int, stride: Int, maxScore: Float): Match? {
        val n = t.sx.size
        var bestSum = maxScore * n * 765f
        var bx = -1; var by = -1
        val xe = minOf(x1, fr.w - t.w); val ye = minOf(y1, fr.h - t.h)
        var y = maxOf(0, y0)
        while (y <= ye) {
            var x = maxOf(0, x0)
            while (x <= xe) {
                var sum = 0f; var i = 0
                while (i < n) {
                    val p = fr.pix[(y + t.sy[i]) * fr.w + x + t.sx[i]]; val q = t.sv[i]
                    sum += Math.abs(((p shr 16) and 255) - ((q shr 16) and 255)) +
                        Math.abs(((p shr 8) and 255) - ((q shr 8) and 255)) +
                        Math.abs((p and 255) - (q and 255))
                    if (sum >= bestSum) break
                    i++
                }
                if (i == n && sum < bestSum) { bestSum = sum; bx = x; by = y }
                x += stride
            }
            y += stride
        }
        return if (bx < 0) null else Match(bx, by, t.w, t.h, bestSum / (n * 765f))
    }

    /** يجرّب عدة مقاييس ويعيد الأفضل. */
    fun findMulti(fr: Frame, ts: TemplateSet, name: String, mults: FloatArray,
                  region: IntArray, stride: Int, maxScore: Float): Match? {
        var best: Match? = null
        for (m in mults) {
            val r = find(fr, ts.get(name, fr.f * m), region[0], region[1], region[2], region[3], stride, maxScore)
            if (r != null && (best == null || r.score < best.score)) best = r
        }
        return best
    }
}
