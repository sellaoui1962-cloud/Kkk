package com.ndr.assistant.core

import android.os.Build
import kotlinx.coroutines.flow.MutableStateFlow

/** The two modes of NDR Room Assistant. Exactly one is active at a time. */
enum class AssistMode { MIC, TAG }

object ModeState {
    val mode = MutableStateFlow(AssistMode.MIC)

    /** TAG mode relies on AccessibilityService.takeScreenshot(), which exists from Android 11 (API 30). */
    val tagSupported: Boolean get() = Build.VERSION.SDK_INT >= 30
}
