package com.ndr.assistant.mic

import android.app.Application
import android.content.Context

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        ctx = applicationContext
        Shell.init()
    }

    companion object {
        lateinit var ctx: Context
    }
}
