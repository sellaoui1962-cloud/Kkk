package com.ndr.assistant.tag.vision

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

data class RawSeat(val cx: Float, val cy: Float, val r: Float, val row: Int, val col: Int,
                   val ring: Float, val textured: Float, val occupied: Boolean, val sig: ByteArray,
                   val locked: Boolean = false, val num: Int = 0, val mine: Boolean = false, val empty: Boolean = false)

/**
 * يكتشف مقاعد المايكات بغضّ النظر عن محتواها (مايك فارغ/مقفل/صورة لاعب) عبر اختبار الحلقة:
 * تباين الإضاءة بين داخل حافة الدائرة وخارجها في كل الاتجاهات. التخطيطات المعروفة (من صورك):
 *  - 4 أعمدة × 3 صفوف (أعمدة 0.125/0.375/0.625/0.875)  - 5 أعمدة × 3 صفوف (0.1/0.3/0.5/0.7/0.9)
 *  - مقعد كبير بالمنتصف + صف من 4.
 * يُختار التخطيط الأعلى مجموعًا، ثم "مشغول" = نسيج صورة (انحراف معياري للحلقة الداخلية ≥ 35).
 * المقاعد الفارغة والمقفلة لا تُرسم عليها دوائر.
 */
class SeatDetector {
    private data class Pos(val x: Float, val y: Float, val r: Float, val row: Int, val col: Int, val labelDy: Float = 0f)

    private val rowsY = floatArrayOf(557f / 1080, 827f / 1080, 1097f / 1080)
    private val rSmall = 75f / 1080
    private val cols4 = FloatArray(4) { (0.125f + 0.25f * it) }
    private val cols5 = FloatArray(5) { (0.1f + 0.2f * it) }

    private val presets: List<List<Pos>> = listOf(
        rowsY.indices.flatMap { r -> cols4.indices.map { c -> Pos(cols4[c], rowsY[r], rSmall, r, c) } },
        rowsY.indices.flatMap { r -> cols5.indices.map { c -> Pos(cols5[c], rowsY[r], rSmall, r, c) } },
        listOf(Pos(0.5f, 578f / 1080, 90f / 1080, 0, 0, 18f)) + cols4.indices.map { Pos(cols4[it], 880f / 1080, rSmall, 1, it) }
    )

    fun ring(fr: Frame, cx: Float, cy: Float, r: Float, thr: Int = 10): Float {
        var ok = 0
        for (k in 0 until 24) {
            val th = 2 * PI * (k + 0.5) / 24
            var a = 0; var b = 0
            for (i in 0 until 4) {
                val ri = r * (0.80f + 0.12f * i / 3f); val ro = r * (1.10f + 0.15f * i / 3f)
                a += fr.lum((cx + ri * cos(th)).toInt(), (cy + ri * sin(th)).toInt())
                b += fr.lum((cx + ro * cos(th)).toInt(), (cy + ro * sin(th)).toInt())
            }
            if (Math.abs(a - b) / 4 > thr) ok++
        }
        return ok / 24f
    }

    private fun texture(fr: Frame, cx: Float, cy: Float, r: Float): Float {
        var n = 0; var s = 0.0; var s2 = 0.0
        for (k in 0 until 48) {
            val th = 2 * PI * k / 48
            for (f in floatArrayOf(0.62f, 0.74f, 0.86f)) {
                val l = fr.lum((cx + f * r * cos(th)).toInt(), (cy + f * r * sin(th)).toInt()).toDouble()
                s += l; s2 += l * l; n++
            }
        }
        val m = s / n
        return sqrt((s2 / n - m * m).coerceAtLeast(0.0)).toFloat()
    }

    /** بصمة صغيرة 8×8 RGB داخل الدائرة، لمقارنة "مايكي". */
    fun signature(fr: Frame, cx: Float, cy: Float, r: Float): ByteArray {
        val out = ByteArray(192); var i = 0
        for (gy in 0 until 8) for (gx in 0 until 8) {
            val x = (cx + (gx - 3.5f) / 3.5f * r * 0.6f).toInt().coerceIn(0, fr.w - 1)
            val y = (cy + (gy - 3.5f) / 3.5f * r * 0.6f).toInt().coerceIn(0, fr.h - 1)
            val p = fr.pix[y * fr.w + x]
            out[i++] = ((p shr 16) and 255).toByte(); out[i++] = ((p shr 8) and 255).toByte(); out[i++] = (p and 255).toByte()
        }
        return out
    }

    private var lastPreset = -1
    private var frameNo = 0

    /** فحص الحافة الأسرع: يجرّب آخر تخطيط ناجح أولًا ولا يمسح كل التخطيطات إلا كل 6 إطارات أو عند فشله. */
    private fun scorePreset(fr: Frame, p: List<Pos>): Pair<Float, List<Pair<Pos, Float>>>? {
        val w = fr.w.toFloat()
        val scored = p.map { it to ring(fr, it.x * w, it.y * w, it.r * w) }
        val strong = scored.count { it.second >= 0.95f }
        if (strong < 1) return null
        return (strong * 10f + scored.sumOf { it.second.toDouble() }.toFloat()) to scored
    }

    private fun teal(fr: Frame, cx: Float, cy: Float, r: Float): Int {
        var n = 0
        val y0 = (cy + r * 1.36f).toInt(); val y1 = (cy + r * 2.24f).toInt()
        val x0 = (cx - r * 1.24f).toInt(); val x1 = (cx + r * 1.24f).toInt()
        for (y in y0..y1 step 2) for (x in x0..x1 step 2) {
            if (x < 0 || y < 0 || x >= fr.w || y >= fr.h) continue
            val p = fr.pix[y * fr.w + x]
            val rr = (p shr 16) and 255; val gg = (p shr 8) and 255; val bb = p and 255
            if (gg > 170 && bb > 140 && rr < 90 && gg - rr > 90) n++
        }
        return n
    }

    fun detect(fr: Frame): List<RawSeat> {
        val w = fr.w.toFloat()
        frameNo++
        var bestScore = -1f; var bestList: List<Pair<Pos, Float>> = emptyList()
        if (lastPreset >= 0 && frameNo % 6 != 0) {
            val r = scorePreset(fr, presets[lastPreset])
            if (r != null) { bestScore = r.first; bestList = r.second }
        }
        if (bestList.isEmpty()) {
            lastPreset = -1
            presets.forEachIndexed { idx, p ->
                val r = scorePreset(fr, p) ?: return@forEachIndexed
                if (r.first > bestScore) { bestScore = r.first; bestList = r.second; lastPreset = idx }
            }
        }
        if (bestList.isEmpty()) return emptyList()
        val validRows = bestList.filter { it.second >= 0.95f }.map { it.first.row }.toSet()   // صف صالح = فيه مقعد واضح
        val kept = bestList.filter { it.first.row in validRows && it.second >= 0.5f }
        // ترقيم كما في اللعبة: من اليمين لليسار صفًّا بعد صف (يشمل المقفل والفارغ)
        val order = kept.sortedWith(compareBy({ it.first.row }, { -it.first.col })).map { it.first }
        return kept.map { (p, rs) ->
            val cx = p.x * w; val cy = p.y * w; val r = p.r * w
            val tx = texture(fr, cx, cy, r)
            val locked = LockMask.score(fr, cx, cy, p.labelDy) >= 0.85f
            val empty = !locked && MicMask.score(fr, cx, cy, r) >= 3.5f
            val mine = !locked && !empty && teal(fr, cx, cy, r) >= 150
            RawSeat(cx, cy, r, p.row, p.col, rs, tx, !locked && !empty, signature(fr, cx, cy, r), locked, order.indexOf(p) + 1, mine, empty)
        }
    }
}
