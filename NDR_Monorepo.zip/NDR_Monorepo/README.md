# NDR Monorepo — build all 3 apps in one push

Contains: NDRRoomAssistant (merged nMic+nTag + MIC/TAG switcher), NDRKeyboard, NDRRoomJoiner.
One push = one GitHub Actions run with 3 parallel jobs, each producing its own debug APK.

## One-time setup (on your own machine, needs internet + a GitHub account)
```bash
unzip NDR_Monorepo.zip
cd NDR_Monorepo
git init
git add .
git commit -m "NDR apps: first build"
# create an empty repo on github.com first (no README/license), then:
git remote add origin https://github.com/<your-username>/<repo-name>.git
git branch -M main
git push -u origin main
```
Pushing triggers `.github/workflows/build-all.yml` automatically — no extra clicks needed.

## Getting the APKs
GitHub repo -> **Actions** tab -> the latest "Build all NDR apps" run -> **Artifacts** section at the
bottom of the run page -> download `NDRRoomAssistant-debug-apk`, `NDRKeyboard-debug-apk`,
`NDRRoomJoiner-debug-apk` (each a zip containing one `app-debug.apk`).

## If a job fails
Click the red ✗ job -> expand the failed step -> copy the error text -> send it back here and I will
fix the source for that project specifically.

## Why I can't just do this myself
This sandbox has no network access and no GitHub credentials, so I can't create a repo or push code
or trigger Actions directly. The workflow above is ready to run the moment you push it.
