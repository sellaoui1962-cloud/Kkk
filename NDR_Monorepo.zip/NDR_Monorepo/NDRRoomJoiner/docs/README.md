# NDR Room Joiner
Standalone app, independent applicationId `com.ndr.joiner`. Does not touch Yalla Ludo's APK.

No officially supported external deep link accepts a room ID (verified: Yalla Ludo's manifest only
declares `com.yallagame://yalla.ludo.route` for events and `com.yallaludo://auth.ludopay.web` for
payment auth — neither takes a room parameter, and the real join call needs the official app's own
authenticated session). So this app: validates the Room ID, checks whether Yalla Ludo is installed,
copies the Room ID to the clipboard, and launches Yalla Ludo so the user can paste it into Yalla
Ludo's own room search. If Yalla Ludo isn't installed, it offers the Play Store listing.

Status: source written, static-checked (XML well-formed, braces/parens balanced in the Kotlin file),
**not compiled** — same sandbox limitation as the other two projects (no Android SDK/Gradle/network
here). Build via the included `.github/workflows/build.yml` or local Gradle + Android SDK 34 / JDK 17.
