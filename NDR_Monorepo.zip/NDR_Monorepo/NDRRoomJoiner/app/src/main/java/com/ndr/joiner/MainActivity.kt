package com.ndr.joiner

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText

/**
 * NDR Room Joiner — standalone app. Does NOT modify, repackage or patch Yalla Ludo.
 *
 * Investigation summary:
 *   Yalla Ludo's AndroidManifest exposes exactly one externally-callable deep link activity,
 *   com.yalla.yallagames.deeplink.DeepLinkRouteActivity, handling two schemes:
 *     com.yallagame://yalla.ludo.route   (observed only with ?eventId=&ActivityID= — activities/events)
 *     com.yallaludo://auth.ludopay.web   (payment-auth callback)
 *   No "room" host or roomId query parameter is declared anywhere in the manifest's
 *   intent-filters, and the room-join flow in the app's own protobuf protocol (LogInRequest /
 *   JoinTheRoomRequest) requires an authenticated session token that only the official client
 *   holds. So there is no supported external mechanism to jump straight into a specific room.
 *   Best legitimate alternative implemented here: copy the Room ID to the clipboard and launch
 *   Yalla Ludo's own launcher activity; the user pastes the ID into Yalla Ludo's own room search
 *   (the app's protocol exposes a room-ID search call, BarSearchRequest/SingleBarXIdSearchRequest,
 *   confirming such a field exists in the official UI).
 */
class MainActivity : AppCompatActivity() {

    companion object {
        const val YALLA_PACKAGE = "com.yalla.yallagames"
    }

    private lateinit var input: TextInputEditText
    private lateinit var joinBtn: MaterialButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        input = findViewById(R.id.roomIdInput)
        joinBtn = findViewById(R.id.joinBtn)
        joinBtn.setOnClickListener { onJoinClicked() }
    }

    private fun onJoinClicked() {
        val raw = input.text?.toString()?.trim().orEmpty()
        if (raw.isEmpty()) { toast(getString(R.string.err_empty)); return }
        if (!raw.all { it.isDigit() }) { toast(getString(R.string.err_format)); return }

        if (!isYallaInstalled()) {
            toast(getString(R.string.err_not_installed))
            offerInstall()
            return
        }

        copyToClipboard(raw)
        toast(getString(R.string.copied))

        val launch = packageManager.getLaunchIntentForPackage(YALLA_PACKAGE)
        if (launch != null) {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(launch)
            toast(getString(R.string.opening))
        } else {
            toast(getString(R.string.err_not_installed))
            offerInstall()
        }
    }

    private fun isYallaInstalled(): Boolean = try {
        packageManager.getPackageInfo(YALLA_PACKAGE, 0)
        true
    } catch (e: PackageManager.NameNotFoundException) {
        false
    }

    private fun copyToClipboard(roomId: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("room_id", roomId))
    }

    private fun offerInstall() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$YALLA_PACKAGE")))
        } catch (e: Exception) {
            startActivity(Intent(Intent.ACTION_VIEW,
                Uri.parse("https://play.google.com/store/apps/details?id=$YALLA_PACKAGE")))
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
